/**
 * SPIN WHEEL - GOOGLE APPS SCRIPT BACKEND
 * 
 * SETUP INSTRUCTIONS:
 * 01. Create a new Google Sheet
 * 02. Go to Extensions > Apps Script
 * 03. Replace Code.gs with this entire script
 * 04. Click Deploy > New Deployment > Web App
 * 05. Execute as: Me
 * 06. Who has access: Anyone
 * 07. Copy the web app URL to your frontend
 * 08. Update ALLOWED_ORIGINS with your website domain
 * 
 * 09. Deployment ID: AKfycbwKBLyzTLsqdfksUp_tRg3StcuD5D4LbPPcBmfGd7dC3RR6d391WCqXc49YJJY1E5IU
 * 10. Web App URL: https://script.google.com/macros/s/AKfycbwEUealh9j0ysQQZ8G9oIBFWX51GAvWWZjEvybENEs3fFLuEQ-elGw46Tc8F0WXMEYN/exec
 */

// ===== CONFIGURATION =====
const CONFIG = {
  SHEET_NAME: 'SpinEntries',
  ALLOWED_ORIGINS: [
    'https://yourwebsite.com',
    'https://www.yourwebsite.com',
    'http://localhost:3000' // For testing
  ],
  // Set to false to strictly enforce ALLOWED_ORIGINS
  ALLOW_ALL_ORIGINS: true,
  RATE_LIMIT: {
    PER_IP: 3,           // Max spins per IP per day
    PER_EMAIL: 1,        // Max spins per email (lifetime)
    PER_PHONE: 1,        // Max spins per phone (lifetime)
    WINDOW_HOURS: 24     // Time window for IP limit
  },
  PRIZES: [
    { label: '₹1000 Voucher', weight: 5, code_prefix: 'VCH1K' },      // 5% chance
    { label: '₹500 Voucher', weight: 10, code_prefix: 'VCH500' },     // 10% chance
    { label: '₹100 Voucher', weight: 15, code_prefix: 'VCH100' },     // 15% chance
    { label: 'Better Luck Next Time', weight: 70, code_prefix: null }  // 70% chance
  ]
};

// ===== MAIN HANDLER =====
function doGet(e) {
  const origin = (e && e.parameter && e.parameter.origin) || '';
  const headers = getCorsHeaders(origin);
  const action = e && e.parameter && e.parameter.action;

  if (action === 'winners') {
    const rawLimit = e && e.parameter && e.parameter.limit ? parseInt(e.parameter.limit, 10) : 6;
    const limit = isNaN(rawLimit) ? 6 : Math.max(1, Math.min(rawLimit, 20));
    const winners = getRecentWinners(limit);
    return createResponse({ success: true, winners: winners }, 200, headers);
  }

  const payload = {
    success: true,
    status: 'ok',
    time: new Date().toISOString(),
    sheet: CONFIG.SHEET_NAME
  };
  return createResponse(payload, 200, headers);
}

function doPost(e) {
  try {
    // Parse request
    const rawBody = e && e.postData && e.postData.contents ? e.postData.contents : '';
    const requestData = rawBody ? JSON.parse(rawBody) : {};
    const origin = (e && e.parameter && e.parameter.origin) || requestData.origin || '';
    
    // CORS Headers
    const headers = getCorsHeaders(origin);

    if (!rawBody) {
      return createResponse({ success: false, error: 'No data received' }, 400, headers);
    }
    
    // Validate origin
    if (!isOriginAllowed(origin)) {
      return createResponse({ success: false, error: 'Origin not allowed' }, 403, headers);
    }
    
    // Validate input
    const validation = validateInput(requestData);
    if (!validation.valid) {
      return createResponse({ success: false, error: validation.error }, 400, headers);
    }
    
    // Sanitize data
    const userData = {
      name: sanitize(requestData.name),
      email: sanitize(requestData.email).toLowerCase(),
      phone: sanitize(requestData.phone),
      ip: sanitize(requestData.ip || 'unknown')
    };
    
    // Check rate limits and duplicates
    const rateCheck = checkRateLimits(userData);
    if (!rateCheck.allowed) {
      return createResponse({ success: false, error: rateCheck.reason }, 429, headers);
    }
    
    // Determine prize (weighted random)
    const prize = selectPrize();
    
    // Generate voucher code if applicable
    const voucherCode = prize.code_prefix ? generateVoucherCode(prize.code_prefix) : null;
    
    // Save to Google Sheet
    const timestamp = new Date();
    const saved = saveToSheet({
      ...userData,
      prize: prize.label,
      voucherCode: voucherCode,
      timestamp: timestamp,
      status: 'pending',
      redemptionDate: null
    });
    
    if (!saved.success) {
      return createResponse({ success: false, error: 'Failed to save data' }, 500, headers);
    }
    
    // Send confirmation email (optional - uncomment if you want)
    // sendConfirmationEmail(userData.email, userData.name, prize.label, voucherCode);
    
    // Return success response
    return createResponse({
      success: true,
      prize: prize.label,
      voucherCode: voucherCode,
      message: voucherCode 
        ? `Congratulations! You won ${prize.label}! Your code: ${voucherCode}`
        : prize.label
    }, 200, headers);
    
  } catch (error) {
    Logger.log('Error in doPost: ' + error.toString());
    return createResponse({ 
      success: false, 
      error: 'Internal server error' 
    }, 500, getCorsHeaders());
  }
}

// ===== PRIZE SELECTION (WEIGHTED RANDOM) =====
function selectPrize() {
  const totalWeight = CONFIG.PRIZES.reduce((sum, prize) => sum + prize.weight, 0);
  let random = Math.random() * totalWeight;
  
  for (let prize of CONFIG.PRIZES) {
    random -= prize.weight;
    if (random <= 0) {
      return prize;
    }
  }
  
  // Fallback (should never reach here)
  return CONFIG.PRIZES[CONFIG.PRIZES.length - 1];
}

// ===== VOUCHER CODE GENERATION =====
function generateVoucherCode(prefix) {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}

// ===== INPUT VALIDATION =====
function validateInput(data) {
  // Check required fields
  if (!data.name || !data.email || !data.phone) {
    return { valid: false, error: 'Missing required fields' };
  }
  
  // Validate name (2-100 characters, letters and spaces only)
  if (!/^[a-zA-Z\s]{2,100}$/.test(data.name)) {
    return { valid: false, error: 'Invalid name format' };
  }
  
  // Validate email
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    return { valid: false, error: 'Invalid email format' };
  }
  
  // Validate phone (Indian format: 10 digits, optionally with +91)
  const phoneClean = data.phone.replace(/[\s\-\(\)]/g, '');
  if (!/^(\+91)?[6-9]\d{9}$/.test(phoneClean)) {
    return { valid: false, error: 'Invalid phone number format' };
  }
  
  // Check for disposable email domains
  const disposableDomains = ['tempmail.com', 'guerrillamail.com', 'mailinator.com', '10minutemail.com'];
  const emailDomain = data.email.split('@')[1].toLowerCase();
  if (disposableDomains.includes(emailDomain)) {
    return { valid: false, error: 'Disposable email addresses are not allowed' };
  }
  
  return { valid: true };
}

// ===== SANITIZATION =====
function sanitize(str) {
  if (!str) return '';
  return str.toString().trim().replace(/[<>]/g, '');
}

// ===== RATE LIMITING & DUPLICATE CHECK =====
function checkRateLimits(userData) {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();
  
  // Skip header row
  const entries = data.slice(1);
  
  // Check email duplicate
  const emailExists = entries.some(row => row[1].toLowerCase() === userData.email);
  if (emailExists) {
    return { 
      allowed: false, 
      reason: 'This email has already participated. Each email can only spin once.' 
    };
  }
  
  // Check phone duplicate
  const phoneClean = userData.phone.replace(/[\s\-\(\)]/g, '');
  const phoneExists = entries.some(row => {
    const existingPhone = row[2].replace(/[\s\-\(\)]/g, '');
    return existingPhone === phoneClean;
  });
  if (phoneExists) {
    return { 
      allowed: false, 
      reason: 'This phone number has already participated. Each number can only spin once.' 
    };
  }
  
  // Check IP rate limit (last 24 hours)
  const now = new Date();
  const windowStart = new Date(now.getTime() - (CONFIG.RATE_LIMIT.WINDOW_HOURS * 60 * 60 * 1000));
  
  const ipCount = entries.filter(row => {
    const entryIp = row[3];
    const entryDate = new Date(row[5]);
    return entryIp === userData.ip && entryDate >= windowStart;
  }).length;
  
  if (ipCount >= CONFIG.RATE_LIMIT.PER_IP) {
    return { 
      allowed: false, 
      reason: `Rate limit exceeded. Maximum ${CONFIG.RATE_LIMIT.PER_IP} spins per day from same IP.` 
    };
  }
  
  return { allowed: true };
}

// ===== RECENT WINNERS =====
function getRecentWinners(limit) {
  try {
    const sheet = getOrCreateSheet();
    const data = sheet.getDataRange().getValues();

    if (data.length <= 1) return [];

    const winners = [];
    for (let i = data.length - 1; i >= 1 && winners.length < limit; i--) {
      const row = data[i];
      const name = row[0];
      const prize = row[4];
      const timestamp = row[5];

      if (!prize) continue;
      if (prize.toString().toLowerCase().indexOf('better luck') !== -1) continue;

      winners.push({
        name: formatWinnerName(name),
        prize: prize.toString(),
        timestamp: timestamp ? new Date(timestamp).toISOString() : null,
        location: 'Online'
      });
    }

    return winners;
  } catch (error) {
    Logger.log('Error fetching winners: ' + error.toString());
    return [];
  }
}

function formatWinnerName(name) {
  if (!name) return 'Someone';
  const cleaned = name.toString().trim();
  if (!cleaned) return 'Someone';
  const parts = cleaned.split(/\s+/);
  if (parts.length === 1) return parts[0];
  const first = parts[0];
  const lastInitial = parts[1] ? parts[1].charAt(0).toUpperCase() + '.' : '';
  return `${first} ${lastInitial}`.trim();
}

// ===== SAVE TO GOOGLE SHEET =====
function saveToSheet(data) {
  try {
    const sheet = getOrCreateSheet();
    
    sheet.appendRow([
      data.name,
      data.email,
      data.phone,
      data.ip,
      data.prize,
      data.timestamp,
      data.voucherCode || '',
      data.status,
      data.redemptionDate || ''
    ]);
    
    return { success: true };
  } catch (error) {
    Logger.log('Error saving to sheet: ' + error.toString());
    return { success: false, error: error.toString() };
  }
}

// ===== GET OR CREATE SHEET =====
function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME);
  
  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.SHEET_NAME);
    // Add headers
    sheet.appendRow([
      'Name', 
      'Email', 
      'Phone', 
      'IP Address', 
      'Prize', 
      'Timestamp', 
      'Voucher Code', 
      'Status', 
      'Redemption Date'
    ]);
    
    // Format header row
    const headerRange = sheet.getRange(1, 1, 1, 9);
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#4285f4');
    headerRange.setFontColor('#ffffff');
    
    // Freeze header row
    sheet.setFrozenRows(1);
    
    // Auto-resize columns
    sheet.autoResizeColumns(1, 9);
  }
  
  return sheet;
}

// ===== CORS HANDLING =====
function getCorsHeaders(origin) {
  const allowAll = CONFIG.ALLOW_ALL_ORIGINS || CONFIG.ALLOWED_ORIGINS.indexOf('*') !== -1;
  const normalizedOrigin = normalizeOrigin(origin);
  const allowedOrigin = allowAll
    ? '*'
    : (isOriginAllowed(normalizedOrigin) ? normalizedOrigin : 'null');
  
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    'Content-Type': 'application/json'
  };
}

function isOriginAllowed(origin) {
  if (CONFIG.ALLOW_ALL_ORIGINS || CONFIG.ALLOWED_ORIGINS.indexOf('*') !== -1) return true;
  if (!origin) return false;
  const normalizedOrigin = normalizeOrigin(origin);
  return CONFIG.ALLOWED_ORIGINS.some(allowed => normalizeOrigin(allowed) === normalizedOrigin);
}

function doOptions(e) {
  const origin = (e && e.parameter && e.parameter.origin) || '';
  return createResponse({}, 200, getCorsHeaders(origin));
}

function normalizeOrigin(origin) {
  if (!origin) return '';
  return origin.toString().trim().replace(/\/$/, '').toLowerCase();
}

// ===== RESPONSE HELPER =====
function createResponse(data, statusCode, headers) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON)
    .setHeaders(headers);
}

// ===== EMAIL NOTIFICATION (OPTIONAL) =====
function sendConfirmationEmail(email, name, prize, voucherCode) {
  try {
    const subject = prize.includes('Better Luck') 
      ? 'Thanks for Participating!' 
      : 'Congratulations! You Won!';
    
    const body = prize.includes('Better Luck')
      ? `Hi ${name},\n\nThank you for participating in our Spin & Win contest!\n\nBetter luck next time!\n\nBest regards,\nYour Team`
      : `Hi ${name},\n\nCongratulations! You won ${prize}!\n\nYour voucher code: ${voucherCode}\n\nRedeem it at: https://yourwebsite.com/redeem\n\nBest regards,\nYour Team`;
    
    MailApp.sendEmail({
      to: email,
      subject: subject,
      body: body
    });
  } catch (error) {
    Logger.log('Error sending email: ' + error.toString());
  }
}

// ===== ADMIN FUNCTIONS =====

/**
 * Get statistics about the spin wheel
 * Call this from a custom menu or trigger
 */
function getStatistics() {
  const sheet = getOrCreateSheet();
  const data = sheet.getDataRange().getValues();
  const entries = data.slice(1);
  
  const stats = {
    totalSpins: entries.length,
    prizeDistribution: {},
    todaySpins: 0,
    uniqueEmails: new Set(),
    uniqueIPs: new Set()
  };
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  entries.forEach(row => {
    const prize = row[4];
    const email = row[1];
    const ip = row[3];
    const timestamp = new Date(row[5]);
    
    // Count prize distribution
    stats.prizeDistribution[prize] = (stats.prizeDistribution[prize] || 0) + 1;
    
    // Count today's spins
    if (timestamp >= today) {
      stats.todaySpins++;
    }
    
    // Track unique emails and IPs
    stats.uniqueEmails.add(email);
    stats.uniqueIPs.add(ip);
  });
  
  stats.uniqueEmails = stats.uniqueEmails.size;
  stats.uniqueIPs = stats.uniqueIPs.size;
  
  Logger.log(JSON.stringify(stats, null, 2));
  return stats;
}

/**
 * Clear old test entries (use with caution!)
 */
function clearTestEntries() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    'Warning',
    'This will delete all entries with "test" in the email. Continue?',
    ui.ButtonSet.YES_NO
  );
  
  if (response === ui.Button.YES) {
    const sheet = getOrCreateSheet();
    const data = sheet.getDataRange().getValues();
    
    for (let i = data.length - 1; i >= 1; i--) {
      if (data[i][1].toLowerCase().includes('test')) {
        sheet.deleteRow(i + 1);
      }
    }
    
    ui.alert('Test entries cleared!');
  }
}

/**
 * Create custom menu for admin functions
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('Spin Wheel Admin')
    .addItem('View Statistics', 'getStatistics')
    .addItem('Clear Test Entries', 'clearTestEntries')
    .addToUi();
}
