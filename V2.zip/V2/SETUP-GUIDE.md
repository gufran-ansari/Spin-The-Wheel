# 🎯 Spin Wheel - Complete Setup Guide

## 📋 Table of Contents
1. [Quick Start](#quick-start)
2. [Google Apps Script Setup](#google-apps-script-setup)
3. [reCAPTCHA Setup](#recaptcha-setup)
4. [Frontend Deployment](#frontend-deployment)
5. [WordPress Integration](#wordpress-integration)
6. [Testing](#testing)
7. [Troubleshooting](#troubleshooting)

---

## 🚀 Quick Start

### What You'll Need:
- Google Account (for Google Sheets & Apps Script)
- Web hosting or WordPress site
- 30 minutes for complete setup
- (Optional) Google reCAPTCHA account

### Overview:
1. Set up Google Sheets backend
2. Deploy Google Apps Script
3. Configure reCAPTCHA (optional but recommended)
4. Deploy frontend HTML
5. Test the complete flow

---

## 📊 Google Apps Script Setup

### Step 1: Create Google Sheet

1. Go to [Google Sheets](https://sheets.google.com)
2. Click "Blank" to create a new spreadsheet
3. Rename it to "Spin Wheel Entries" or similar
4. Keep this tab open

### Step 2: Open Apps Script Editor

1. In your Google Sheet, click **Extensions** > **Apps Script**
2. You'll see a new tab with `Code.gs` file
3. Delete any existing code in `Code.gs`

### Step 3: Add Backend Code

1. Copy the entire content from `google-apps-script-backend.js`
2. Paste it into `Code.gs`
3. **Important**: Update the `ALLOWED_ORIGINS` in the CONFIG section:

```javascript
ALLOWED_ORIGINS: [
    'https://yourwebsite.com',        // Replace with your domain
    'https://www.yourwebsite.com',    // Replace with www version
    'http://localhost:3000'           // Keep for testing
],
```

### Step 4: Deploy as Web App

1. Click **Deploy** > **New Deployment**
2. Click the gear icon ⚙️ next to "Select type"
3. Choose **Web app**
4. Configure:
   - **Description**: "Spin Wheel Backend v1"
   - **Execute as**: Me (your email)
   - **Who has access**: Anyone
5. Click **Deploy**
6. **Authorize access** when prompted:
   - Click "Review Permissions"
   - Choose your Google account
   - Click "Advanced" → "Go to [Project Name] (unsafe)"
   - Click "Allow"
7. **Copy the Web App URL** - it looks like:
   ```
   https://script.google.com/macros/s/AKfycbz.../exec
   ```
8. Save this URL - you'll need it for the frontend!

### Step 5: Test the Backend

1. In Apps Script, click **Run** > **Run function** > `onOpen`
2. Go back to your Google Sheet
3. You should see a new menu: "Spin Wheel Admin"
4. The sheet should now have a header row with columns:
   - Name, Email, Phone, IP Address, Prize, Timestamp, Voucher Code, Status, Redemption Date

---

## 🛡️ reCAPTCHA Setup (Optional but Recommended)

### Step 1: Register Your Site

1. Go to [Google reCAPTCHA Admin](https://www.google.com/recaptcha/admin)
2. Click **+** to create a new site
3. Fill in:
   - **Label**: "Spin Wheel"
   - **reCAPTCHA type**: reCAPTCHA v3
   - **Domains**: Add your domain (e.g., `yourwebsite.com`)
4. Accept Terms of Service
5. Click **Submit**

### Step 2: Get Your Keys

1. Copy your **Site Key** (starts with `6L...`)
2. Copy your **Secret Key** (starts with `6L...`)
3. Save both keys securely

### Step 3: Add to Apps Script (Optional)

If you want server-side validation:

1. In your Apps Script `Code.gs`, add this function:

```javascript
function verifyRecaptcha(token) {
  const SECRET_KEY = 'YOUR_SECRET_KEY_HERE';
  const url = 'https://www.google.com/recaptcha/api/siteverify';
  
  const payload = {
    secret: SECRET_KEY,
    response: token
  };
  
  const options = {
    method: 'post',
    payload: payload
  };
  
  const response = UrlFetchApp.fetch(url, options);
  const result = JSON.parse(response.getContentText());
  
  return result.success && result.score > 0.5;
}
```

2. In the `doPost` function, add verification:

```javascript
// After parsing requestData
if (requestData.recaptchaToken) {
  const isHuman = verifyRecaptcha(requestData.recaptchaToken);
  if (!isHuman) {
    return createResponse({ success: false, error: 'reCAPTCHA verification failed' }, 403, headers);
  }
}
```

---

## 🌐 Frontend Deployment

### Step 1: Update Configuration

Open `enhanced-spin-wheel.html` and update these values:

```javascript
const CONFIG = {
    GOOGLE_SCRIPT_URL: "YOUR_WEB_APP_URL_HERE",  // Paste the URL from Step 4 above
    RECAPTCHA_SITE_KEY: "YOUR_SITE_KEY_HERE",    // If using reCAPTCHA
    // ... rest of config
};
```

### Step 2: Deploy to Your Server

**Option A: Standalone HTML**
1. Upload `enhanced-spin-wheel.html` to your web server
2. Access it via `https://yourwebsite.com/spin-wheel.html`

**Option B: WordPress** (See next section)

**Option C: Embed in Existing Page**
1. Copy everything between `<body>` tags
2. Paste into your page
3. Copy the `<style>` section to your CSS file
4. Copy the `<script>` section to your JS file

---

## 🔧 WordPress Integration

### Method 1: Simple Page (Recommended for Beginners)

1. **Login to WordPress Admin**
2. **Pages** > **Add New**
3. **Click the three dots** (⋮) > **Code editor**
4. Paste the entire content of `enhanced-spin-wheel.html`
5. **Publish**

### Method 2: Shortcode Plugin

Create a custom plugin:

1. Create file: `wp-content/plugins/spin-wheel/spin-wheel.php`

```php
<?php
/**
 * Plugin Name: Spin Wheel
 * Description: Interactive spin wheel with Google Sheets integration
 * Version: 1.0
 * Author: Your Name
 */

function spin_wheel_shortcode() {
    ob_start();
    include(plugin_dir_path(__FILE__) . 'spin-wheel.html');
    return ob_get_clean();
}
add_shortcode('spin_wheel', 'spin_wheel_shortcode');

function spin_wheel_scripts() {
    wp_enqueue_script('recaptcha', 'https://www.google.com/recaptcha/api.js?render=YOUR_SITE_KEY', [], null, true);
}
add_action('wp_enqueue_scripts', 'spin_wheel_scripts');
```

2. Create file: `wp-content/plugins/spin-wheel/spin-wheel.html`
   - Paste the content from `enhanced-spin-wheel.html` (without `<html>`, `<head>`, `<body>` tags)

3. **Activate plugin** in WordPress admin
4. Use shortcode: `[spin_wheel]` in any page/post

### Method 3: Elementor/Page Builder

1. Add **HTML widget**
2. Paste the HTML code
3. Adjust styling as needed

---

## 🧪 Testing

### Pre-Launch Checklist

- [ ] Backend URL is correct in frontend config
- [ ] CORS origins are set correctly
- [ ] Test with a real email/phone
- [ ] Verify data appears in Google Sheet
- [ ] Test duplicate email prevention
- [ ] Test duplicate phone prevention
- [ ] Test IP rate limiting
- [ ] Check mobile responsiveness
- [ ] Verify prize distribution (run multiple tests)
- [ ] Test error handling (invalid inputs)
- [ ] Check voucher code generation
- [ ] Test on different browsers (Chrome, Firefox, Safari)

### Testing Script

Run this in your browser console after submitting:

```javascript
// Check localStorage
console.log('Last Spin:', localStorage.getItem('lastSpinTime'));
console.log('Email:', localStorage.getItem('lastSpinEmail'));

// Try spinning again (should be blocked)
// Should show "already spun" error
```

### Clearing Test Data

**Clear Google Sheet:**
1. Go to your Google Sheet
2. Click "Spin Wheel Admin" > "Clear Test Entries"
3. This removes all entries with "test" in email

**Clear Browser Data:**
```javascript
// Run in browser console
localStorage.clear();
location.reload();
```

---

## 🐛 Troubleshooting

### Issue: "Origin not allowed" error

**Solution:**
1. Check `ALLOWED_ORIGINS` in Apps Script
2. Make sure your domain is listed
3. Redeploy the Apps Script
4. Clear browser cache

### Issue: Data not saving to Google Sheet

**Solution:**
1. Check Apps Script execution log:
   - Apps Script > **Executions** tab
   - Look for errors
2. Verify permissions are granted
3. Check if sheet name matches `CONFIG.SHEET_NAME`

### Issue: Wheel spins but no prize shown

**Solution:**
1. Open browser console (F12)
2. Check for JavaScript errors
3. Verify response format from backend
4. Check if `result.prize` matches prize labels exactly

### Issue: reCAPTCHA not working

**Solution:**
1. Verify Site Key is correct
2. Check domain is registered in reCAPTCHA admin
3. Ensure script tag is loading:
   ```html
   <script src="https://www.google.com/recaptcha/api.js?render=SITE_KEY"></script>
   ```
4. Check browser console for reCAPTCHA errors

### Issue: Can't spin again after first attempt

**Expected behavior!** This is the duplicate prevention system working.

**To test again:**
1. Use a different email
2. Clear localStorage: `localStorage.clear()`
3. Wait 24 hours (IP limit)
4. Or clear test entries from Google Sheet

### Issue: Mobile layout broken

**Solution:**
1. Check viewport meta tag is present
2. Test with browser dev tools mobile mode
3. Adjust breakpoints in CSS if needed
4. Reduce wheel size on mobile:
   ```css
   @media (max-width: 768px) {
       .wheel-container {
           transform: scale(0.7);
       }
   }
   ```

### Issue: CORS errors

**Solution:**
1. Redeploy Apps Script
2. Ensure `doOptions` function is present
3. Check browser console for exact error
4. Verify fetch headers match allowed headers

---

## 📊 Monitoring & Analytics

### Google Sheet Analytics

Use the built-in admin function:

```javascript
function getStatistics() {
  // Shows: Total spins, prize distribution, unique users, etc.
}
```

Call from: **Spin Wheel Admin** > **View Statistics**

### Add Google Analytics

Add to your HTML `<head>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

Track events:

```javascript
// After successful spin
gtag('event', 'wheel_spin', {
  'event_category': 'engagement',
  'event_label': result.prize,
  'value': result.voucherCode ? 1 : 0
});
```

---

## 🔐 Security Best Practices

1. **Never expose Secret Keys** in frontend code
2. **Always use HTTPS** in production
3. **Enable reCAPTCHA** to prevent bots
4. **Regularly review** Google Sheet entries for suspicious activity
5. **Set up email alerts** for high-value prizes
6. **Backup your Google Sheet** regularly
7. **Monitor API usage** in Apps Script dashboard
8. **Update ALLOWED_ORIGINS** to only include your domains

---

## 🎨 Customization

### Change Prize Pool

Edit in Apps Script `CODE.gs`:

```javascript
PRIZES: [
    { label: '₹2000 Voucher', weight: 2, code_prefix: 'VCH2K' },   // 2% chance
    { label: '₹1000 Voucher', weight: 5, code_prefix: 'VCH1K' },   // 5% chance
    { label: '₹500 Voucher', weight: 10, code_prefix: 'VCH500' },  // 10% chance
    { label: 'Better Luck Next Time', weight: 83, code_prefix: null } // 83% chance
]
```

**Important:** After changing prizes, also update frontend `CONFIG.PRIZES` to match!

### Change Colors

Edit CSS variables in `enhanced-spin-wheel.html`:

```css
:root {
    --primary-gold: #YOUR_COLOR;
    --accent-red: #YOUR_COLOR;
    --dark-bg: #YOUR_COLOR;
}
```

### Change Rate Limits

Edit in Apps Script:

```javascript
RATE_LIMIT: {
    PER_IP: 5,           // Change from 3 to 5
    PER_EMAIL: 1,        
    PER_PHONE: 1,        
    WINDOW_HOURS: 24     
}
```

---

## 📞 Support

### Common Questions

**Q: Can I use this commercially?**
A: Yes, but ensure compliance with local lottery/gambling laws.

**Q: Can I customize the design?**
A: Absolutely! All code is customizable.

**Q: How many entries can Google Sheets handle?**
A: Google Sheets supports up to 5 million cells (about 500k entries with 10 columns).

**Q: Can I add more form fields?**
A: Yes! Add to both frontend HTML and Apps Script validation.

**Q: Is this GDPR compliant?**
A: You need to add:
- Privacy policy link
- Cookie consent banner
- Data deletion mechanism
- Terms & conditions

---

## 🚀 Next Steps

1. ✅ Complete setup following this guide
2. 🧪 Test thoroughly before launch
3. 📱 Optimize for mobile
4. 🎨 Customize branding
5. 📊 Set up analytics
6. 🔒 Enable reCAPTCHA
7. 📧 Set up email notifications
8. 🎯 Launch and monitor!

---

## 📄 Files Included

1. `enhanced-spin-wheel.html` - Production-ready frontend
2. `google-apps-script-backend.js` - Backend with security
3. `SETUP-GUIDE.md` - This guide
4. `spin-wheel-improvements.md` - Detailed improvement list

---

## ⚠️ Important Notes

- Test EVERYTHING before going live
- Set up proper CORS to prevent unauthorized access
- Monitor your Google Sheet regularly
- Back up your data
- Comply with local regulations regarding prizes/contests

---

**Need Help?** Check the Troubleshooting section or review the execution logs in Apps Script.

Good luck with your Spin Wheel! 🎯🎉
