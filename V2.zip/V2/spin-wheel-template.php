<?php
/**
 * Spin Wheel Template
 * This file is included by the WordPress plugin
 * 
 * Available variables:
 * - $google_script_url: The Google Apps Script URL
 * - $recaptcha_site_key: reCAPTCHA site key (if configured)
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}
?>

<style>
    /* Spin Wheel Styles - Scoped to avoid conflicts */
    .spin-wheel-wrapper {
        font-family: 'DM Sans', sans-serif;
        color: #ffffff;
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px 20px;
    }
    
    .spin-wheel-wrapper * {
        box-sizing: border-box;
    }
    
    .spin-wheel-wrapper h1, 
    .spin-wheel-wrapper h2, 
    .spin-wheel-wrapper h3 {
        font-family: 'Sora', sans-serif;
    }
    
    /* Rest of the styles from enhanced-spin-wheel.html */
    /* Copy all styles here but prefix with .spin-wheel-wrapper to avoid conflicts */
    
    .spin-wheel-wrapper .animated-bg {
        position: absolute;
        inset: 0;
        z-index: 0;
        pointer-events: none;
        opacity: 0.6;
    }
    
    .spin-wheel-wrapper .wheel-container {
        position: relative;
        filter: drop-shadow(0 0 40px rgba(255, 184, 0, 0.3));
    }
    
    .spin-wheel-wrapper .wheel-transition {
        transition: transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99);
    }
    
    /* Add all other styles here... */
</style>

<div class="spin-wheel-wrapper" style="background: #0A0A0A; border-radius: 20px; padding: 60px 40px; position: relative; overflow: hidden;">
    
    <!-- Background effects -->
    <div class="animated-bg"></div>
    
    <!-- Wheel content -->
    <div class="relative z-10">
        <!-- Copy the HTML structure from enhanced-spin-wheel.html -->
        <!-- But remove <html>, <head>, <body> tags -->
        
        <div class="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <!-- LEFT: Wheel Section -->
            <div class="flex flex-col items-center justify-center">
                <div class="relative wheel-container">
                    <!-- Pointer -->
                    <div class="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-5 z-30" style="pointer-events: none;">
                        <div style="width: 0; height: 0; border-left: 16px solid transparent; border-right: 16px solid transparent; border-bottom: 24px solid #ff3b3b;"></div>
                    </div>

                    <!-- Wheel -->
                    <div style="position: relative; padding: 24px; border-radius: 50%; background: linear-gradient(to bottom right, #262626, #171717); box-shadow: 0 25px 50px -12px rgba(0,0,0,0.8); border: 8px solid #404040;">
                        <svg id="spin-wheel-svg" viewBox="0 0 100 100" style="width: 320px; height: 320px; position: relative; z-index: 10;" class="wheel-transition">
                            <!-- Segments added by JavaScript -->
                        </svg>

                        <!-- Center circle -->
                        <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; z-index: 20; pointer-events: none;">
                            <div style="width: 64px; height: 64px; background: #171717; border-radius: 50%; border: 4px solid #525252; display: flex; align-items: center; justify-content: center; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);">
                                <div style="width: 16px; height: 16px; background: white; border-radius: 50%; box-shadow: 0 0 15px white;"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Prize display -->
                <div id="spin-prize-display" style="margin-top: 48px; display: none;">
                    <div style="background: linear-gradient(to right, #fbbf24, #f59e0b); color: black; padding: 20px 40px; border-radius: 9999px; font-weight: 900; font-size: 24px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <span>🎊</span>
                            <span id="spin-prize-text"></span>
                            <span>🎊</span>
                        </div>
                    </div>
                    <div id="spin-voucher-display" style="margin-top: 16px; text-align: center; display: none;">
                        <div style="background: rgba(255,255,255,0.1); backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.2); border-radius: 16px; padding: 16px 24px;">
                            <p style="font-size: 14px; color: #9ca3af; margin-bottom: 4px;">Your Voucher Code:</p>
                            <p id="spin-voucher-code" style="font-size: 24px; font-family: monospace; font-weight: bold; color: #fbbf24;"></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT: Form Section -->
            <div>
                <div style="background: rgba(26,26,26,0.6); backdrop-filter: blur(32px); border: 1px solid rgba(255,255,255,0.1); border-radius: 32px; padding: 48px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);">
                    <div style="margin-bottom: 32px;">
                        <h2 style="font-size: 48px; font-weight: 900; margin-bottom: 16px; line-height: 1; background: linear-gradient(to right, #fbbf24, #f59e0b, #d97706); background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                            SPIN & WIN
                        </h2>
                        <p style="color: #9ca3af; font-size: 16px;">Enter your details to unlock your chance at winning exciting prizes!</p>
                    </div>

                    <form id="spin-wheel-form" style="display: flex; flex-direction: column; gap: 20px;" novalidate>
                        <!-- Name -->
                        <div>
                            <label style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em; font-weight: bold; color: #6b7280; margin-left: 8px; display: block; margin-bottom: 8px;">
                                Full Name <span style="color: #ef4444;">*</span>
                            </label>
                            <input 
                                required 
                                type="text" 
                                id="spin-user-name" 
                                name="name"
                                placeholder="Rajesh Kumar"
                                style="width: 100%; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 16px 20px; color: white; transition: all 0.3s;"
                                pattern="[a-zA-Z\s]{2,100}"
                            >
                            <p id="spin-name-error" style="font-size: 12px; color: #f87171; margin-left: 8px; margin-top: 4px; display: none;">Please enter a valid name</p>
                        </div>

                        <!-- Email -->
                        <div>
                            <label style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em; font-weight: bold; color: #6b7280; margin-left: 8px; display: block; margin-bottom: 8px;">
                                Email Address <span style="color: #ef4444;">*</span>
                            </label>
                            <input 
                                required 
                                type="email" 
                                id="spin-user-email" 
                                name="email"
                                placeholder="rajesh@example.com"
                                style="width: 100%; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 16px 20px; color: white; transition: all 0.3s;"
                            >
                            <p id="spin-email-error" style="font-size: 12px; color: #f87171; margin-left: 8px; margin-top: 4px; display: none;">Please enter a valid email</p>
                        </div>

                        <!-- Phone -->
                        <div>
                            <label style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em; font-weight: bold; color: #6b7280; margin-left: 8px; display: block; margin-bottom: 8px;">
                                Phone Number <span style="color: #ef4444;">*</span>
                            </label>
                            <input 
                                required 
                                type="tel" 
                                id="spin-user-phone" 
                                name="phone"
                                placeholder="+91 98765 43210"
                                style="width: 100%; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 16px 20px; color: white; transition: all 0.3s;"
                            >
                            <p id="spin-phone-error" style="font-size: 12px; color: #f87171; margin-left: 8px; margin-top: 4px; display: none;">Please enter a valid phone number</p>
                        </div>

                        <!-- Honeypot -->
                        <input type="text" name="website" style="display:none;" tabindex="-1">

                        <!-- Error message -->
                        <div id="spin-error-msg" style="display: none; padding: 16px; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); border-radius: 12px; color: #f87171; font-size: 14px;">
                            <span id="spin-error-text"></span>
                        </div>

                        <!-- Button -->
                        <button 
                            type="submit" 
                            id="spin-submit-btn"
                            style="width: 100%; background: linear-gradient(to right, #fbbf24, #f59e0b); color: black; font-weight: 900; padding: 20px; border-radius: 16px; box-shadow: 0 20px 40px -10px rgba(251,191,36,0.4); transition: all 0.3s; text-transform: uppercase; letter-spacing: 0.05em; font-size: 18px; border: none; cursor: pointer; margin-top: 24px;"
                        >
                            <span id="spin-btn-text">🎯 Spin Now</span>
                        </button>

                        <p style="font-size: 12px; color: #6b7280; text-align: center; margin-top: 16px;">
                            By spinning, you agree to our Terms & Conditions
                        </p>
                    </form>

                    <!-- Trust signals -->
                    <div style="margin-top: 32px; padding-top: 24px; border-top: 1px solid rgba(255,255,255,0.05); display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 12px; text-align: center;">
                            <p style="font-size: 12px; color: #6b7280; margin-bottom: 4px;">🔒 Secure</p>
                            <p style="font-size: 12px; font-weight: bold;">SSL Encrypted</p>
                        </div>
                        <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 12px; text-align: center;">
                            <p style="font-size: 12px; color: #6b7280; margin-bottom: 4px;">✓ Verified</p>
                            <p style="font-size: 12px; font-weight: bold;" id="spin-display-ip">IP: Loading...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
(function() {
    'use strict';
    
    // Configuration
    const CONFIG = {
        GOOGLE_SCRIPT_URL: '<?php echo esc_js($google_script_url); ?>',
        RECAPTCHA_SITE_KEY: '<?php echo esc_js($recaptcha_site_key); ?>',
        PRIZES: [
            { label: '₹1000 Voucher', color: '#FFD700', text: '#000' },
            { label: '₹500 Voucher', color: '#C0C0C0', text: '#000' },
            { label: '₹100 Voucher', color: '#A0A0A0', text: '#000' },
            { label: 'Better Luck Next Time', color: '#1a1a1a', text: '#fff' }
        ]
    };
    
    // DOM elements
    const wheelSvg = document.getElementById('spin-wheel-svg');
    const form = document.getElementById('spin-wheel-form');
    const submitBtn = document.getElementById('spin-submit-btn');
    const prizeDisplay = document.getElementById('spin-prize-display');
    const prizeText = document.getElementById('spin-prize-text');
    const voucherDisplay = document.getElementById('spin-voucher-display');
    const voucherCode = document.getElementById('spin-voucher-code');
    const errorMsg = document.getElementById('spin-error-msg');
    const errorText = document.getElementById('spin-error-text');
    const displayIp = document.getElementById('spin-display-ip');
    
    // State
    let currentRotation = 0;
    let userIp = '';
    let isSpinning = false;
    const requestOrigin = (window.location && window.location.origin && window.location.origin !== 'null')
        ? window.location.origin
        : '';

    const storage = {
        get: function(key) {
            try { return localStorage.getItem(key); } catch (e) { return null; }
        },
        set: function(key, value) {
            try { localStorage.setItem(key, value); } catch (e) { /* ignore */ }
        }
    };

    function buildEndpointUrl(baseUrl, origin) {
        if (!origin) return baseUrl;
        const joiner = baseUrl.indexOf('?') === -1 ? '?' : '&';
        return baseUrl + joiner + 'origin=' + encodeURIComponent(origin);
    }
    
    // Initialize
    async function init() {
        await fetchIP();
        initWheel();
        checkIfAlreadySpun();
    }
    
    // Fetch IP
    async function fetchIP() {
        try {
            const res = await fetch('https://api.ipify.org?format=json');
            const data = await res.json();
            userIp = data.ip;
            if (displayIp) displayIp.textContent = 'IP: ' + userIp;
        } catch (e) {
            userIp = 'unknown';
            if (displayIp) displayIp.textContent = 'IP: Verified';
        }
    }
    
    // Initialize wheel
    function initWheel() {
        const anglePerSegment = 360 / CONFIG.PRIZES.length;
        
        CONFIG.PRIZES.forEach((prize, i) => {
            const rotation = i * anglePerSegment;
            const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
            g.setAttribute("transform", `rotate(${rotation} 50 50)`);
            
            const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
            path.setAttribute("d", "M 50 50 L 50 0 A 50 50 0 0 1 100 50 Z");
            path.setAttribute("fill", prize.color);
            path.setAttribute("stroke", "#000");
            path.setAttribute("stroke-width", "0.5");
            
            const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
            text.setAttribute("x", "75");
            text.setAttribute("y", "28");
            text.setAttribute("fill", prize.text);
            text.setAttribute("font-size", "3.5");
            text.setAttribute("font-weight", "900");
            text.setAttribute("text-anchor", "middle");
            text.setAttribute("transform", `rotate(${anglePerSegment/2} 75 28)`);
            
            const words = prize.label.split(' ');
            words.forEach((word, index) => {
                const tspan = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
                tspan.setAttribute("x", "75");
                tspan.setAttribute("dy", index === 0 ? "0" : "4.5");
                tspan.textContent = word;
                text.appendChild(tspan);
            });
            
            g.appendChild(path);
            g.appendChild(text);
            wheelSvg.appendChild(g);
        });
    }
    
    // Check if already spun
    function checkIfAlreadySpun() {
        const lastSpin = storage.get('lastSpinTime');
        if (lastSpin) {
            const hoursSince = (Date.now() - parseInt(lastSpin)) / (1000 * 60 * 60);
            if (hoursSince < 24) {
                showError(`You've already spun today! Come back in ${Math.ceil(24 - hoursSince)} hours.`);
                submitBtn.disabled = true;
            }
        }
    }
    
    // Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (isSpinning) return;
        
        const name = document.getElementById('spin-user-name').value;
        const email = document.getElementById('spin-user-email').value;
        const phone = document.getElementById('spin-user-phone').value;
        
        // Basic validation
        if (!name || !email || !phone) {
            showError('Please fill all fields');
            return;
        }
        
        isSpinning = true;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing...';
        
        try {
            const payload = { name, email, phone, ip: userIp, origin: requestOrigin };
            const endpointUrl = buildEndpointUrl(CONFIG.GOOGLE_SCRIPT_URL, requestOrigin);
            
            const response = await fetch(endpointUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
                body: JSON.stringify(payload)
            });
            
            const rawText = await response.text();
            let result;
            try {
                result = JSON.parse(rawText);
            } catch (parseError) {
                throw new Error('Unexpected server response. Please check your Apps Script deployment.');
            }
            
            if (!response.ok || !result.success) {
                throw new Error(result.error || 'Something went wrong');
            }
            
            storage.set('lastSpinTime', Date.now().toString());
            storage.set('lastSpinEmail', email);
            
            await animateWheel(result.prize);
            showPrize(result.prize, result.voucherCode);
            
        } catch (error) {
            const message = error && error.message ? error.message : 'Network error. Please try again.';
            if (message === 'Failed to fetch') {
                showError('Network/CORS error. Please verify your Apps Script deployment and allowed origins.');
            } else {
                showError(message);
            }
            isSpinning = false;
            submitBtn.disabled = false;
            submitBtn.textContent = '🎯 Spin Now';
        }
    });
    
    // Animate wheel
    async function animateWheel(prizeName) {
        return new Promise((resolve) => {
            let prizeIndex = CONFIG.PRIZES.findIndex(p => p.label === prizeName);
            if (prizeIndex < 0) prizeIndex = 0;
            const anglePerSegment = 360 / CONFIG.PRIZES.length;
            const extraSpins = 360 * 8;
            const targetRotation = (360 - (prizeIndex * anglePerSegment)) - (anglePerSegment / 2);
            
            currentRotation += extraSpins + targetRotation;
            wheelSvg.style.transform = `rotate(${currentRotation}deg)`;
            
            setTimeout(resolve, 4000);
        });
    }
    
    // Show prize
    function showPrize(prize, code) {
        prizeText.textContent = prize;
        prizeDisplay.style.display = 'block';
        
        if (code) {
            voucherCode.textContent = code;
            voucherDisplay.style.display = 'block';
        }
        
        submitBtn.textContent = '✓ Done';
    }
    
    // Show error
    function showError(message) {
        errorText.textContent = message;
        errorMsg.style.display = 'block';
        setTimeout(() => errorMsg.style.display = 'none', 5000);
    }
    
    // Start
    init();
})();
</script>
