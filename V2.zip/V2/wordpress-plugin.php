<?php
/**
 * Plugin Name: Spin & Win Wheel
 * Plugin URI: https://yourwebsite.com
 * Description: Interactive spin wheel game with Google Sheets integration, duplicate prevention, and security features
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: spin-wheel
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SPIN_WHEEL_VERSION', '1.0.0');
define('SPIN_WHEEL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SPIN_WHEEL_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main Spin Wheel Class
 */
class Spin_Wheel {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Register shortcode
        add_shortcode('spin_wheel', array($this, 'render_spin_wheel'));
        
        // Enqueue scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'Spin Wheel Settings',
            'Spin Wheel',
            'manage_options',
            'spin-wheel-settings',
            array($this, 'settings_page'),
            'dashicons-games',
            30
        );
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting('spin_wheel_settings', 'spin_wheel_google_script_url');
        register_setting('spin_wheel_settings', 'spin_wheel_recaptcha_site_key');
        register_setting('spin_wheel_settings', 'spin_wheel_recaptcha_secret_key');
        register_setting('spin_wheel_settings', 'spin_wheel_enable_analytics');
        register_setting('spin_wheel_settings', 'spin_wheel_analytics_id');
    }
    
    /**
     * Settings page HTML
     */
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>🎯 Spin Wheel Settings</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('spin_wheel_settings'); ?>
                <?php do_settings_sections('spin_wheel_settings'); ?>
                
                <table class="form-table">
                    <!-- Google Apps Script URL -->
                    <tr>
                        <th scope="row">
                            <label for="spin_wheel_google_script_url">Google Apps Script URL</label>
                        </th>
                        <td>
                            <input 
                                type="url" 
                                id="spin_wheel_google_script_url" 
                                name="spin_wheel_google_script_url" 
                                value="<?php echo esc_attr(get_option('spin_wheel_google_script_url')); ?>" 
                                class="regular-text"
                                required
                            >
                            <p class="description">
                                Your Google Apps Script web app URL (ends with /exec)
                                <br>Example: https://script.google.com/macros/s/ABC.../exec
                            </p>
                        </td>
                    </tr>
                    
                    <!-- reCAPTCHA Site Key -->
                    <tr>
                        <th scope="row">
                            <label for="spin_wheel_recaptcha_site_key">reCAPTCHA Site Key</label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="spin_wheel_recaptcha_site_key" 
                                name="spin_wheel_recaptcha_site_key" 
                                value="<?php echo esc_attr(get_option('spin_wheel_recaptcha_site_key')); ?>" 
                                class="regular-text"
                            >
                            <p class="description">
                                Optional: Get from <a href="https://www.google.com/recaptcha/admin" target="_blank">Google reCAPTCHA</a>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- reCAPTCHA Secret Key -->
                    <tr>
                        <th scope="row">
                            <label for="spin_wheel_recaptcha_secret_key">reCAPTCHA Secret Key</label>
                        </th>
                        <td>
                            <input 
                                type="password" 
                                id="spin_wheel_recaptcha_secret_key" 
                                name="spin_wheel_recaptcha_secret_key" 
                                value="<?php echo esc_attr(get_option('spin_wheel_recaptcha_secret_key')); ?>" 
                                class="regular-text"
                            >
                            <p class="description">Keep this secret! Never share publicly.</p>
                        </td>
                    </tr>
                    
                    <!-- Enable Analytics -->
                    <tr>
                        <th scope="row">
                            <label for="spin_wheel_enable_analytics">Enable Google Analytics</label>
                        </th>
                        <td>
                            <input 
                                type="checkbox" 
                                id="spin_wheel_enable_analytics" 
                                name="spin_wheel_enable_analytics" 
                                value="1" 
                                <?php checked(1, get_option('spin_wheel_enable_analytics'), true); ?>
                            >
                            <label for="spin_wheel_enable_analytics">Track spin events in Google Analytics</label>
                        </td>
                    </tr>
                    
                    <!-- Analytics ID -->
                    <tr>
                        <th scope="row">
                            <label for="spin_wheel_analytics_id">Google Analytics ID</label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="spin_wheel_analytics_id" 
                                name="spin_wheel_analytics_id" 
                                value="<?php echo esc_attr(get_option('spin_wheel_analytics_id')); ?>" 
                                class="regular-text"
                                placeholder="G-XXXXXXXXXX"
                            >
                            <p class="description">Your Google Analytics 4 Measurement ID</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Save Settings'); ?>
            </form>
            
            <hr>
            
            <h2>📖 How to Use</h2>
            <div class="card">
                <h3>1. Setup Google Apps Script</h3>
                <p>Follow the setup guide to deploy your Google Apps Script backend.</p>
                
                <h3>2. Add to Page</h3>
                <p>Use the shortcode <code>[spin_wheel]</code> in any page or post.</p>
                
                <h3>3. Customization</h3>
                <p>Edit the wheel prizes and colors in the Google Apps Script configuration.</p>
            </div>
            
            <hr>
            
            <h2>🛠️ System Status</h2>
            <table class="widefat">
                <tr>
                    <td><strong>Google Script URL:</strong></td>
                    <td>
                        <?php 
                        $url = get_option('spin_wheel_google_script_url');
                        if ($url) {
                            echo '<span style="color: green;">✓ Configured</span>';
                        } else {
                            echo '<span style="color: red;">✗ Not configured</span>';
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><strong>reCAPTCHA:</strong></td>
                    <td>
                        <?php 
                        $recaptcha = get_option('spin_wheel_recaptcha_site_key');
                        if ($recaptcha) {
                            echo '<span style="color: green;">✓ Enabled</span>';
                        } else {
                            echo '<span style="color: orange;">⚠ Disabled (recommended to enable)</span>';
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><strong>Analytics:</strong></td>
                    <td>
                        <?php 
                        $analytics = get_option('spin_wheel_enable_analytics');
                        if ($analytics) {
                            echo '<span style="color: green;">✓ Enabled</span>';
                        } else {
                            echo '<span style="color: gray;">○ Disabled</span>';
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><strong>Plugin Version:</strong></td>
                    <td><?php echo SPIN_WHEEL_VERSION; ?></td>
                </tr>
            </table>
        </div>
        
        <style>
            .card {
                background: #fff;
                padding: 20px;
                margin: 20px 0;
                border-left: 4px solid #2271b1;
            }
            .widefat td {
                padding: 10px;
            }
        </style>
        <?php
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Check if we're on a page with the shortcode
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'spin_wheel')) {
            
            // Google Fonts
            wp_enqueue_style(
                'spin-wheel-fonts',
                'https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;700&display=swap',
                array(),
                null
            );
            
            // reCAPTCHA (if enabled)
            $recaptcha_key = get_option('spin_wheel_recaptcha_site_key');
            if ($recaptcha_key) {
                wp_enqueue_script(
                    'google-recaptcha',
                    'https://www.google.com/recaptcha/api.js?render=' . $recaptcha_key,
                    array(),
                    null,
                    true
                );
            }
            
            // Google Analytics (if enabled)
            if (get_option('spin_wheel_enable_analytics')) {
                $ga_id = get_option('spin_wheel_analytics_id');
                if ($ga_id) {
                    wp_enqueue_script(
                        'google-analytics',
                        'https://www.googletagmanager.com/gtag/js?id=' . $ga_id,
                        array(),
                        null,
                        false
                    );
                    
                    // Initialize GA
                    wp_add_inline_script('google-analytics', "
                        window.dataLayer = window.dataLayer || [];
                        function gtag(){dataLayer.push(arguments);}
                        gtag('js', new Date());
                        gtag('config', '{$ga_id}');
                    ");
                }
            }
        }
    }
    
    /**
     * Render spin wheel shortcode
     */
    public function render_spin_wheel($atts) {
        // Get settings
        $google_script_url = get_option('spin_wheel_google_script_url');
        $recaptcha_site_key = get_option('spin_wheel_recaptcha_site_key', '');
        
        // Check if Google Script URL is configured
        if (empty($google_script_url)) {
            if (current_user_can('manage_options')) {
                return '<div style="padding: 20px; background: #ffebee; border: 1px solid #f44336; border-radius: 4px;">
                    <strong>Spin Wheel Error:</strong> Please configure the Google Apps Script URL in 
                    <a href="' . admin_url('admin.php?page=spin-wheel-settings') . '">plugin settings</a>.
                </div>';
            }
            return '<div style="padding: 20px; background: #f5f5f5; border-radius: 4px;">
                Spin Wheel is currently unavailable. Please try again later.
            </div>';
        }
        
        // Start output buffering
        ob_start();
        
        // Include the HTML template
        include SPIN_WHEEL_PLUGIN_DIR . 'templates/spin-wheel-template.php';
        
        return ob_get_clean();
    }
}

// Initialize plugin
function spin_wheel_init() {
    return Spin_Wheel::get_instance();
}
add_action('plugins_loaded', 'spin_wheel_init');

/**
 * Activation hook
 */
function spin_wheel_activate() {
    // Set default options
    add_option('spin_wheel_google_script_url', '');
    add_option('spin_wheel_recaptcha_site_key', '');
    add_option('spin_wheel_recaptcha_secret_key', '');
    add_option('spin_wheel_enable_analytics', 0);
    add_option('spin_wheel_analytics_id', '');
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'spin_wheel_activate');

/**
 * Deactivation hook
 */
function spin_wheel_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'spin_wheel_deactivate');

/**
 * Uninstall hook
 */
function spin_wheel_uninstall() {
    // Remove options if user wants to delete data
    delete_option('spin_wheel_google_script_url');
    delete_option('spin_wheel_recaptcha_site_key');
    delete_option('spin_wheel_recaptcha_secret_key');
    delete_option('spin_wheel_enable_analytics');
    delete_option('spin_wheel_analytics_id');
}
register_uninstall_hook(__FILE__, 'spin_wheel_uninstall');
